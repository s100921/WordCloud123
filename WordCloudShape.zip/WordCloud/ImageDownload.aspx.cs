﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;


public partial class ImageDownload : System.Web.UI.Page
{
    //My code

    public string GetConnectionString()
    {
        //sets the connection string from your web config file "ConnString" is the name of your Connection String
        return System.Configuration.ConfigurationManager.ConnectionStrings["WC_Database"].ConnectionString;
    }


    public string userid
    {
        get
        {
            if (HttpContext.Current.Session["USER_ID"] != null)
            {
                return Session["USER_ID"].ToString();
            }
            else
            {
                return "";
            }

        }
    }


    protected void Page_Load(object sender, EventArgs e)
    {


        DataTable dt = new DataTable();
        String strConnString = System.Configuration.ConfigurationManager.ConnectionStrings["WC_Database"].ConnectionString;
        //string strQuery = "SELECT id, Filename FROM tblFiles2 ORDER BY id";



        string strQuery = "SELECT * FROM tblFiles WHERE Username = @Username ORDER BY id";

        SqlConnection conn = new SqlConnection(GetConnectionString());
        conn.Open();

        SqlCommand cmd = new SqlCommand(strQuery, conn);
        cmd.Parameters.Add("@Username", SqlDbType.VarChar).Value = userid;
        SqlConnection con = new SqlConnection(strConnString);
        SqlDataAdapter sda = new SqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        try
        {
            con.Open();
            sda.SelectCommand = cmd;
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            con.Close();
            sda.Dispose();
            con.Dispose();
        }


    }


    protected void DownloadFile(object sender, EventArgs e)
    {

        int id = int.Parse((sender as LinkButton).CommandArgument);
        byte[] bytes;
        string fileName, contentType;
        string constr = System.Configuration.ConfigurationManager.ConnectionStrings["WC_Database"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "SELECT Filename, Data, ContentType from tblFiles where Id=@Id";
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    sdr.Read();
                    bytes = (byte[])sdr["Data"];
                    contentType = sdr["ContentType"].ToString();
                    fileName = sdr["Filename"].ToString();
                }
                con.Close();
            }
        }
        Response.Clear();
        Response.Buffer = true;
        Response.Charset = "";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = contentType;
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + fileName);
        Response.BinaryWrite(bytes);
        Response.Flush();
        Response.End();

    }


    //protected void DeleteFile(object sender, EventArgs e)
    //{
    //    int id = int.Parse((sender as LinkButton).CommandArgument);
    //    byte[] bytes;
    //    string fileName, contentType;
    //    string constr = System.Configuration.ConfigurationManager.ConnectionStrings["WC_Database"].ConnectionString;
    //    using (SqlConnection con = new SqlConnection(constr))
    //    {
    //        using (SqlCommand cmd = new SqlCommand())
    //        {
    //            cmd.CommandText = "DELETE Filename, Data, ContentType from tblFiles where Id=@Id";
    //            cmd.Parameters.AddWithValue("@Id", id);
    //            cmd.Connection = con;
    //            con.Open();

    //            //cmd.ExecuteNonQuery();
    //            //using (SqlDataReader sdr = cmd.ExecuteNonQuery())
    //            using (SqlDataReader sdr = cmd.ExecuteReader())
    //            {


    //                sdr.Read();
    //                bytes = (byte[])sdr["Data"];
    //                contentType = sdr["ContentType"].ToString();
    //                fileName = sdr["Filename"].ToString();
    //            }
    //            con.Close();
    //        }
    //    }

    //}


    //protected void DeleteFile(object sender, EventArgs e)
    //{
    //    //string userid = HttpContext.Current.Session["USER_ID"].ToString();
    //    string filename = string.Empty;

    //    DataTable dt = new DataTable();
    //    String strConnString = System.Configuration.ConfigurationManager.ConnectionStrings["WC_Database"].ConnectionString;
    //    //string strQuery = "SELECT id, Filename FROM tblFiles2 ORDER BY id";

    //    //int rowIndex = Convert.ToInt32(e.CommandArgument);
    //    //int imgid = Convert.ToInt32(GridView1.DataKeys[rowIndex].Value);


    //    // DELETE ALL RECORD FROM SQL SERVER DATABASE
    //    string strQuery = "DELETE FROM tblFiles WHERE Username = @Username";

    //    SqlConnection conn = new SqlConnection(GetConnectionString());
    //    conn.Open();

    //    SqlCommand cmd = new SqlCommand(strQuery, conn);
    //    cmd.Parameters.Add("@Username", SqlDbType.VarChar).Value = userid;
    //    SqlConnection con = new SqlConnection(strConnString);
    //    SqlDataAdapter sda = new SqlDataAdapter();
    //    cmd.CommandType = CommandType.Text;
    //    cmd.Connection = con;
    //    try
    //    {
    //        con.Open();
    //        sda.SelectCommand = cmd;
    //        sda.Fill(dt);
    //        GridView1.DataSource = dt;
    //        GridView1.DataBind();
    //    }
    //    catch (Exception ex)
    //    {
    //        Response.Write(ex.Message);
    //    }
    //    finally
    //    {
    //        con.Close();
    //        sda.Dispose();
    //        con.Dispose();
    //    }
    //}
}
